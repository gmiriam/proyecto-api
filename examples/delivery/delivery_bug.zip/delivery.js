module.exports = {
	main: function (a, b) {

		return a - b;
	}
};
